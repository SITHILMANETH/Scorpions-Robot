#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

Adafruit_PWMServoDriver pca9685 = Adafruit_PWMServoDriver(0x40);

// ================= Servo pulse range =================
#define SERVOMIN 110
#define SERVOMAX 510

// ================= FR leg channels =================
#define FR1 4
#define FR2 8
#define FR3 12

// ================= BL leg channels =================
#define BL1 5
#define BL2 9
#define BL3 13

// ================= Home / Stand pose =================
int fr1_home = 90;
int fr2_home = 45;
int fr3_home = 55;

int bl1_home = 90;
int bl2_home = 45;
int bl3_home = 55;

// ================= Current positions =================
int fr1_cur = fr1_home;
int fr2_cur = fr2_home;
int fr3_cur = fr3_home;

int bl1_cur = bl1_home;
int bl2_cur = bl2_home;
int bl3_cur = bl3_home;

bool walking = false;

// =====================================================
int angleToPulse(int angle) {
  return map(angle, 0, 180, SERVOMIN, SERVOMAX);
}

void setServo(uint8_t ch, int angle) {
  angle = constrain(angle, 0, 180);
  pca9685.setPWM(ch, 0, angleToPulse(angle));
}

// ================= Move FR and BL smoothly =================
void movePairSmooth(int fr1_t, int fr2_t, int fr3_t,
                    int bl1_t, int bl2_t, int bl3_t,
                    int steps = 25, int dly = 15) {
  int fr1_s = fr1_cur;
  int fr2_s = fr2_cur;
  int fr3_s = fr3_cur;

  int bl1_s = bl1_cur;
  int bl2_s = bl2_cur;
  int bl3_s = bl3_cur;

  for (int i = 1; i <= steps; i++) {
    int a_fr1 = fr1_s + (fr1_t - fr1_s) * i / steps;
    int a_fr2 = fr2_s + (fr2_t - fr2_s) * i / steps;
    int a_fr3 = fr3_s + (fr3_t - fr3_s) * i / steps;

    int a_bl1 = bl1_s + (bl1_t - bl1_s) * i / steps;
    int a_bl2 = bl2_s + (bl2_t - bl2_s) * i / steps;
    int a_bl3 = bl3_s + (bl3_t - bl3_s) * i / steps;

    setServo(FR1, a_fr1);
    setServo(FR2, a_fr2);
    setServo(FR3, a_fr3);

    setServo(BL1, a_bl1);
    setServo(BL2, a_bl2);
    setServo(BL3, a_bl3);

    delay(dly);
  }

  fr1_cur = fr1_t;
  fr2_cur = fr2_t;
  fr3_cur = fr3_t;

  bl1_cur = bl1_t;
  bl2_cur = bl2_t;
  bl3_cur = bl3_t;
}

// ================= Go to stand pose =================
void FR_BL_home() {
  movePairSmooth(
    fr1_home, fr2_home, fr3_home,
    bl1_home, bl2_home, bl3_home,
    30, 15
  );
}

// ================= One walking step =================
void FR_BL_walkStep() {
  // 1. lift both legs
  movePairSmooth(
    90, 70, 40,
    90, 70, 40,
    25, 15
  );

  // 2. swing forward
  movePairSmooth(
    65, 70, 40,
    65, 70, 40,
    25, 15
  );

  // 3. place down
  movePairSmooth(
    65, 45, 55,
    65, 45, 55,
    25, 15
  );

  // 4. push back
  movePairSmooth(
    115, 45, 55,
    115, 45, 55,
    30, 15
  );

  // 5. return to stand
  movePairSmooth(
    90, 45, 55,
    90, 45, 55,
    25, 15
  );
}

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);

  pca9685.begin();
  pca9685.setPWMFreq(50);
  delay(500);

  // Initial stand pose
  setServo(FR1, fr1_home);
  setServo(FR2, fr2_home);
  setServo(FR3, fr3_home);

  setServo(BL1, bl1_home);
  setServo(BL2, bl2_home);
  setServo(BL3, bl3_home);

  Serial.println("FR + BL READY");
  Serial.println("H = Stand Pose");
  Serial.println("W = Start Walking");
  Serial.println("S = Stop Walking");
}

void loop() {
  if (Serial.available()) {
    char cmd = Serial.read();

    if (cmd == 'H' || cmd == 'h') {
      walking = false;
      FR_BL_home();
    }

    if (cmd == 'W' || cmd == 'w') {
      walking = true;
    }

    if (cmd == 'S' || cmd == 's') {
      walking = false;
    }
  }

  if (walking) {
    FR_BL_walkStep();
  }
}