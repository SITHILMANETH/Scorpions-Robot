// Non-blocking version with 30cm threshold
#define TRIG_FRONT 27
#define ECHO_FRONT 26
#define TRIG_LEFT 32
#define ECHO_LEFT 33
#define TRIG_RIGHT 14
#define ECHO_RIGHT 12

// Threshold distance in cm
const float THRESHOLD = 30.0;

struct Sensor {
  int trigPin;
  int echoPin;
  float distance;
  unsigned long lastTriggerTime;
  bool waitingForEcho;
  unsigned long echoStartTime;
  bool obstacleDetected;  // New flag for obstacle detection
};

Sensor sensors[3] = {
  {TRIG_FRONT, ECHO_FRONT, 0, 0, false, 0, false},
  {TRIG_LEFT, ECHO_LEFT, 0, 0, false, 0, false},
  {TRIG_RIGHT, ECHO_RIGHT, 0, 0, false, 0, false}
};

const unsigned long TRIGGER_INTERVAL = 50; // 50ms between sensor triggers
unsigned long lastTrigger = 0;
int currentSensor = 0;

// LED pins for visual indication (optional)
#define LED_FRONT 2
#define LED_LEFT 4
#define LED_RIGHT 5

void setup() {
  Serial.begin(115200);
  
  for (int i = 0; i < 3; i++) {
    pinMode(sensors[i].trigPin, OUTPUT);
    pinMode(sensors[i].echoPin, INPUT);
    digitalWrite(sensors[i].trigPin, LOW);
  }
  
  // Optional: Setup LEDs for visual feedback
  pinMode(LED_FRONT, OUTPUT);
  pinMode(LED_LEFT, OUTPUT);
  pinMode(LED_RIGHT, OUTPUT);
  
  digitalWrite(LED_FRONT, LOW);
  digitalWrite(LED_LEFT, LOW);
  digitalWrite(LED_RIGHT, LOW);
  
  Serial.println("Multi-sensor ultrasonic system ready");
  Serial.println("Threshold: 30cm");
  Serial.println("-------------------");
}

void loop() {
  unsigned long currentTime = millis();
  
  // Trigger sensors sequentially
  if (!sensors[currentSensor].waitingForEcho && 
      currentTime - lastTrigger >= TRIGGER_INTERVAL) {
    
    // Trigger current sensor
    digitalWrite(sensors[currentSensor].trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(sensors[currentSensor].trigPin, LOW);
    
    sensors[currentSensor].waitingForEcho = true;
    sensors[currentSensor].echoStartTime = micros();
    lastTrigger = currentTime;
    
    // Move to next sensor
    currentSensor = (currentSensor + 1) % 3;
  }
  
  // Check for echoes
  for (int i = 0; i < 3; i++) {
    if (sensors[i].waitingForEcho) {
      int duration = pulseIn(sensors[i].echoPin, HIGH, 30000);
      if (duration > 0) {
        sensors[i].distance = duration * 0.0343 / 2;
        sensors[i].waitingForEcho = false;
        
        // Check if obstacle is within threshold
        if (sensors[i].distance > 0 && sensors[i].distance <= THRESHOLD) {
          sensors[i].obstacleDetected = true;
        } else {
          sensors[i].obstacleDetected = false;
        }
      } else if (micros() - sensors[i].echoStartTime > 30000) {
        sensors[i].distance = 999.0; // Timeout (no obstacle)
        sensors[i].waitingForEcho = false;
        sensors[i].obstacleDetected = false;
      }
    }
  }
  
  // Update LEDs based on threshold (optional)
  updateLEDs();
  
  // Print all distances and warnings every 200ms
  static unsigned long lastPrint = 0;
  if (currentTime - lastPrint >= 200) {
    lastPrint = currentTime;
    
    // Print distances
    Serial.print("F:");
    Serial.print(sensors[0].distance, 1);
    Serial.print("cm ");
    Serial.print("L:");
    Serial.print(sensors[1].distance, 1);
    Serial.print("cm ");
    Serial.print("R:");
    Serial.print(sensors[2].distance, 1);
    Serial.print("cm ");
    
    // Print warning if any obstacle within threshold
    bool anyObstacle = false;
    if (sensors[0].obstacleDetected) {
      Serial.print(" FRONT < 30cm! ");
      anyObstacle = true;
    }
    if (sensors[1].obstacleDetected) {
      Serial.print(" LEFT < 30cm! ");
      anyObstacle = true;
    }
    if (sensors[2].obstacleDetected) {
      Serial.print(" RIGHT < 30cm! ");
      anyObstacle = true;
    }
    
    if (!anyObstacle) {
      Serial.print("✓ CLEAR ");
    }
    
    Serial.println();
  }
}

// Optional: Update LEDs based on obstacle detection
void updateLEDs() {
  digitalWrite(LED_FRONT, sensors[0].obstacleDetected ? HIGH : LOW);
  digitalWrite(LED_LEFT, sensors[1].obstacleDetected ? HIGH : LOW);
  digitalWrite(LED_RIGHT, sensors[2].obstacleDetected ? HIGH : LOW);
}