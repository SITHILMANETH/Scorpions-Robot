#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

Adafruit_PWMServoDriver pca9685 = Adafruit_PWMServoDriver(0x40);

// ================= Servo pulse range =================
#define SERVOMIN 110
#define SERVOMAX 510

// ================= Servo Mapping =================
// FR
#define FR1 4
#define FR2 8
#define FR3 12

// BL
#define BL1 5
#define BL2 9
#define BL3 13

// FL
#define FL1 6
#define FL2 10
#define FL3 14

// BR
#define BR1 7
#define BR2 11
#define BR3 15

// ================= Home Positions =================
// All legs have same home position (90, 45, 55)
int FR_home[3] = {90, 45, 55};
int BL_home[3] = {90, 45, 55};
int FL_home[3] = {90, 45, 55};
int BR_home[3] = {90, 45, 55};

// ================= Current Positions =================
int FR_cur[3] = {90, 45, 55};
int BL_cur[3] = {90, 45, 55};
int FL_cur[3] = {90, 45, 55};
int BR_cur[3] = {90, 45, 55};

bool walking = false;

// =====================================================
int angleToPulse(int angle) {
  return map(angle, 0, 180, SERVOMIN, SERVOMAX);
}

void setServo(uint8_t ch, int angle) {
  angle = constrain(angle, 0, 180);
  pca9685.setPWM(ch, 0, angleToPulse(angle));
}

// ================= Mirror Angle for FL and BR =================
// FL and BR need angles mirrored relative to home position
// Home for all legs is 90° for motor1, 45° for motor2, 55° for motor3
// For mirrored legs: angle = home - (angle - home)
// Which simplifies to: angle = 2*home - original_angle

int mirrorForFLBR(int angle, int homeAngle) {
  return constrain(2 * homeAngle - angle, 0, 180);
}

// ================= Smooth Move Function =================
void moveLegs(
  int FR_t[3], int BL_t[3],
  int FL_t[3], int BR_t[3],
  int steps = 25, int dly = 15
) {

  int FR_s[3] = {FR_cur[0], FR_cur[1], FR_cur[2]};
  int BL_s[3] = {BL_cur[0], BL_cur[1], BL_cur[2]};
  int FL_s[3] = {FL_cur[0], FL_cur[1], FL_cur[2]};
  int BR_s[3] = {BR_cur[0], BR_cur[1], BR_cur[2]};

  for (int i = 1; i <= steps; i++) {

    int fr1 = FR_s[0] + (FR_t[0] - FR_s[0]) * i / steps;
    int fr2 = FR_s[1] + (FR_t[1] - FR_s[1]) * i / steps;
    int fr3 = FR_s[2] + (FR_t[2] - FR_s[2]) * i / steps;

    int bl1 = BL_s[0] + (BL_t[0] - BL_s[0]) * i / steps;
    int bl2 = BL_s[1] + (BL_t[1] - BL_s[1]) * i / steps;
    int bl3 = BL_s[2] + (BL_t[2] - BL_s[2]) * i / steps;

    int fl1 = FL_s[0] + (FL_t[0] - FL_s[0]) * i / steps;
    int fl2 = FL_s[1] + (FL_t[1] - FL_s[1]) * i / steps;
    int fl3 = FL_s[2] + (FL_t[2] - FL_s[2]) * i / steps;

    int br1 = BR_s[0] + (BR_t[0] - BR_s[0]) * i / steps;
    int br2 = BR_s[1] + (BR_t[1] - BR_s[1]) * i / steps;
    int br3 = BR_s[2] + (BR_t[2] - BR_s[2]) * i / steps;

    // Apply to servos
    setServo(FR1, fr1);
    setServo(FR2, fr2);
    setServo(FR3, fr3);

    setServo(BL1, bl1);
    setServo(BL2, bl2);
    setServo(BL3, bl3);

    setServo(FL1, fl1);
    setServo(FL2, fl2);
    setServo(FL3, fl3);

    setServo(BR1, br1);
    setServo(BR2, br2);
    setServo(BR3, br3);

    delay(dly);
  }

  for (int j = 0; j < 3; j++) {
    FR_cur[j] = FR_t[j];
    BL_cur[j] = BL_t[j];
    FL_cur[j] = FL_t[j];
    BR_cur[j] = BR_t[j];
  }
}

// ================= Stand =================
void standPose() {
  moveLegs(FR_home, BL_home, FL_home, BR_home);
}

// ================= Walk Cycle =================
// FR and BL use original angles
// FL and BR use mirrored angles relative to home

void walkStep1() {
  // FR and BL moving forward (original angles)
  int FRBL_lift[3]  = {90, 70, 40};    // Lift position
  int FRBL_swing[3] = {65, 70, 40};    // Swing forward position
  int FRBL_down[3]  = {65, 45, 55};    // Place down position
  int FRBL_push[3]  = {115, 45, 55};   // Push backward position
  
  // FL and BR remain in push position (mirrored)
  // Mirror of push {115,45,55} relative to home {90,45,55}
  int FLBR_push[3] = {
    mirrorForFLBR(115, 90),   // Motor1: 2*90 - 115 = 65
    mirrorForFLBR(45, 45),    // Motor2: 2*45 - 45 = 45
    mirrorForFLBR(55, 55)     // Motor3: 2*55 - 55 = 55
  };
  
  // Step 1: Lift FR and BL
  moveLegs(FRBL_lift, FRBL_lift, FLBR_push, FLBR_push);
  
  // Step 2: Swing FR and BL forward
  moveLegs(FRBL_swing, FRBL_swing, FLBR_push, FLBR_push);
  
  // Step 3: Place FR and BL down
  moveLegs(FRBL_down, FRBL_down, FLBR_push, FLBR_push);
  
  // Step 4: Push FR and BL backward
  moveLegs(FRBL_push, FRBL_push, FLBR_push, FLBR_push);
}

void walkStep2() {
  // FR and BL remain in push position (original angles)
  int FRBL_push[3] = {115, 45, 55};
  
  // FL and BR moving forward (mirrored angles relative to home)
  int FLBR_lift[3] = {
    mirrorForFLBR(90, 90),    // Motor1: 2*90 - 90 = 90
    mirrorForFLBR(70, 45),    // Motor2: 2*45 - 70 = 20
    mirrorForFLBR(40, 55)     // Motor3: 2*55 - 40 = 70
  };
  
  int FLBR_swing[3] = {
    mirrorForFLBR(65, 90),    // Motor1: 2*90 - 65 = 115
    mirrorForFLBR(70, 45),    // Motor2: 2*45 - 70 = 20
    mirrorForFLBR(40, 55)     // Motor3: 2*55 - 40 = 70
  };
  
  int FLBR_down[3] = {
    mirrorForFLBR(65, 90),    // Motor1: 2*90 - 65 = 115
    mirrorForFLBR(45, 45),    // Motor2: 2*45 - 45 = 45
    mirrorForFLBR(55, 55)     // Motor3: 2*55 - 55 = 55
  };
  
  int FLBR_push[3] = {
    mirrorForFLBR(115, 90),   // Motor1: 2*90 - 115 = 65
    mirrorForFLBR(45, 45),    // Motor2: 2*45 - 45 = 45
    mirrorForFLBR(55, 55)     // Motor3: 2*55 - 55 = 55
  };
  
  // Step 1: Lift FL and BR
  moveLegs(FRBL_push, FRBL_push, FLBR_lift, FLBR_lift);
  
  // Step 2: Swing FL and BR forward
  moveLegs(FRBL_push, FRBL_push, FLBR_swing, FLBR_swing);
  
  // Step 3: Place FL and BR down
  moveLegs(FRBL_push, FRBL_push, FLBR_down, FLBR_down);
  
  // Step 4: Push FL and BR backward
  moveLegs(FRBL_push, FRBL_push, FLBR_push, FLBR_push);
}

// ================= Setup =================
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  
  pca9685.begin();
  pca9685.setPWMFreq(50);
  
  delay(500);
  
  standPose();
  
  Serial.println("Quadruped Ready");
  Serial.println("Commands:");
  Serial.println("H/h - Home/Stand");
  Serial.println("W/w - Start Walking");
  Serial.println("S/s - Stop Walking");
}

// ================= Loop =================
void loop() {
  if (Serial.available()) {
    char cmd = Serial.read();
    
    if (cmd == 'H' || cmd == 'h') {
      walking = false;
      standPose();
      Serial.println("Home position");
    }
    
    if (cmd == 'W' || cmd == 'w') {
      walking = true;
      Serial.println("Walking started");
    }
    
    if (cmd == 'S' || cmd == 's') {
      walking = false;
      Serial.println("Walking stopped");
    }
  }
  
  if (walking) {
    walkStep1();
    walkStep2();
  }
}