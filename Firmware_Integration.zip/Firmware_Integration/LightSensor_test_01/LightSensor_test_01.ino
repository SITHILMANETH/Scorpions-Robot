#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>
#include <BH1750.h>

// ================= I2C DEVICES =================
Adafruit_PWMServoDriver pca9685 = Adafruit_PWMServoDriver(0x40);
BH1750 lightMeter;

// ================= SETUP =================
void setup() {
  Serial.begin(115200);

  // Start I2C (same for both devices)
  Wire.begin(21, 22);

  // Optional: make I2C stable
  Wire.setClock(100000);

  // Initialize Servo Driver
  pca9685.begin();
  pca9685.setPWMFreq(50);

  // Initialize Light Sensor
  if (lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE)) {
    Serial.println("BH1750 Ready");
  } else {
    Serial.println("BH1750 NOT detected!");
  }

  Serial.println("System Ready");
}

// ================= LOOP =================
void loop() {
  float lux = lightMeter.readLightLevel();

  Serial.print("Light Intensity: ");
  Serial.print(lux);
  Serial.println(" lx");

  delay(300);  // Only affects printing, NOT motor driver
}