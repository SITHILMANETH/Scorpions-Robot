#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

Adafruit_PWMServoDriver pca9685 = Adafruit_PWMServoDriver(0x40);

// ================= ULTRASONIC =================
#define TRIG_FRONT 27
#define ECHO_FRONT 26
#define TRIG_LEFT 32
#define ECHO_LEFT 33
#define TRIG_RIGHT 14
#define ECHO_RIGHT 12

const float THRESHOLD = 30.0;

struct Sensor {
  int trigPin;
  int echoPin;
  float distance;
  bool obstacleDetected;
};

Sensor sensors[3] = {
  {TRIG_FRONT, ECHO_FRONT, 0, false},
  {TRIG_LEFT, ECHO_LEFT, 0, false},
  {TRIG_RIGHT, ECHO_RIGHT, 0, false}
};

// ================= SERVO =================
#define SERVOMIN 110
#define SERVOMAX 510

#define FR1 4
#define FR2 8
#define FR3 12

#define BL1 5
#define BL2 9
#define BL3 13

#define FL1 6
#define FL2 10
#define FL3 14

#define BR1 7
#define BR2 11
#define BR3 15

int FR_home[3] = {90, 45, 55};
int BL_home[3] = {90, 45, 55};
int FL_home[3] = {90, 45, 55};
int BR_home[3] = {90, 45, 55};

int FR_cur[3] = {90, 45, 55};
int BL_cur[3] = {90, 45, 55};
int FL_cur[3] = {90, 45, 55};
int BR_cur[3] = {90, 45, 55};

enum MoveState { IDLE, FORWARD, BACKWARD, TURN_LEFT, TURN_RIGHT };
MoveState currentState = IDLE;

int steps = 20;
int dly = 10;

// ================= BASIC =================
int angleToPulse(int angle) {
  return map(angle, 0, 180, SERVOMIN, SERVOMAX);
}

void setServo(uint8_t ch, int angle) {
  angle = constrain(angle, 0, 180);
  pca9685.setPWM(ch, 0, angleToPulse(angle));
}

// ================= MIRROR =================
int mirrorForFL(int angle, int homeAngle) {
  return constrain(2 * homeAngle - angle, 0, 180);
}

int mirrorForBL(int angle, int motorNum, int homeAngle) {
  return (motorNum == 1) ? constrain(2 * homeAngle - angle, 0, 180) : angle;
}

int mirrorForBR(int angle, int motorNum, int homeAngle) {
  return (motorNum == 2) ? constrain(2 * homeAngle - angle, 0, 180) : angle;
}

// ================= MOVE LEG =================
void moveLeg(int leg, int target[3], int stepsNum = 20, int delayTime = 10) {
  int* current;
  int ch1, ch2, ch3;

  if (leg == 0) { current = FR_cur; ch1 = FR1; ch2 = FR2; ch3 = FR3; }
  else if (leg == 1) { current = BL_cur; ch1 = BL1; ch2 = BL2; ch3 = BL3; }
  else if (leg == 2) { current = FL_cur; ch1 = FL1; ch2 = FL2; ch3 = FL3; }
  else { current = BR_cur; ch1 = BR1; ch2 = BR2; ch3 = BR3; }

  int s1 = current[0], s2 = current[1], s3 = current[2];

  for (int i = 1; i <= stepsNum; i++) {
    setServo(ch1, s1 + (target[0] - s1) * i / stepsNum);
    setServo(ch2, s2 + (target[1] - s2) * i / stepsNum);
    setServo(ch3, s3 + (target[2] - s3) * i / stepsNum);
    delay(delayTime);
  }

  current[0] = target[0];
  current[1] = target[1];
  current[2] = target[2];
}

// ================= POSE =================
void standPose() {
  moveLeg(0, FR_home);
  moveLeg(1, BL_home);
  moveLeg(2, FL_home);
  moveLeg(3, BR_home);
}

// ================= FORWARD =================
void forwardStepFR() {
  int lift[3]={90,70,40}, swing[3]={65,70,40}, down[3]={65,45,55}, push[3]={115,45,55};
  moveLeg(0,lift,steps,dly); moveLeg(0,swing,steps,dly); moveLeg(0,down,steps,dly); moveLeg(0,push,steps,dly);
}

void forwardStepBL() {
  int lift[3]={mirrorForBL(90,1,90),mirrorForBL(70,2,45),mirrorForBL(40,3,55)};
  int swing[3]={mirrorForBL(65,1,90),mirrorForBL(70,2,45),mirrorForBL(40,3,55)};
  int down[3]={mirrorForBL(65,1,90),mirrorForBL(45,2,45),mirrorForBL(55,3,55)};
  int push[3]={mirrorForBL(115,1,90),mirrorForBL(45,2,45),mirrorForBL(55,3,55)};
  moveLeg(1,lift,steps,dly); moveLeg(1,swing,steps,dly); moveLeg(1,down,steps,dly); moveLeg(1,push,steps,dly);
}

void forwardStepFL() {
  int lift[3]={mirrorForFL(90,90),mirrorForFL(70,45),mirrorForFL(40,55)};
  int swing[3]={mirrorForFL(65,90),mirrorForFL(70,45),mirrorForFL(40,55)};
  int down[3]={mirrorForFL(65,90),mirrorForFL(45,45),mirrorForFL(55,55)};
  int push[3]={mirrorForFL(115,90),mirrorForFL(45,45),mirrorForFL(55,55)};
  moveLeg(2,lift,steps,dly); moveLeg(2,swing,steps,dly); moveLeg(2,down,steps,dly); moveLeg(2,push,steps,dly);
}

void forwardStepBR() {
  int lift[3]={mirrorForBR(90,1,90),mirrorForBR(70,2,45),mirrorForBR(40,3,55)};
  int swing[3]={mirrorForBR(65,1,90),mirrorForBR(70,2,45),mirrorForBR(40,3,55)};
  int down[3]={mirrorForBR(65,1,90),mirrorForBR(45,2,45),mirrorForBR(55,3,55)};
  int push[3]={mirrorForBR(115,1,90),mirrorForBR(45,2,45),mirrorForBR(55,3,55)};
  moveLeg(3,lift,steps,dly); moveLeg(3,swing,steps,dly); moveLeg(3,down,steps,dly); moveLeg(3,push,steps,dly);
}

// ================= BACKWARD =================
void backwardStepFR() {
  int lift[3]={90,70,40}, swing[3]={115,70,40}, down[3]={115,45,55}, push[3]={65,45,55};
  moveLeg(0,lift,steps,dly); moveLeg(0,swing,steps,dly); moveLeg(0,down,steps,dly); moveLeg(0,push,steps,dly);
}

void backwardStepBL() {
  int lift[3]={mirrorForBL(90,1,90),mirrorForBL(70,2,45),mirrorForBL(40,3,55)};
  int swing[3]={mirrorForBL(115,1,90),mirrorForBL(70,2,45),mirrorForBL(40,3,55)};
  int down[3]={mirrorForBL(115,1,90),mirrorForBL(45,2,45),mirrorForBL(55,3,55)};
  int push[3]={mirrorForBL(65,1,90),mirrorForBL(45,2,45),mirrorForBL(55,3,55)};
  moveLeg(1,lift,steps,dly); moveLeg(1,swing,steps,dly); moveLeg(1,down,steps,dly); moveLeg(1,push,steps,dly);
}

void backwardStepFL() {
  int lift[3]={mirrorForFL(90,90),mirrorForFL(70,45),mirrorForFL(40,55)};
  int swing[3]={mirrorForFL(115,90),mirrorForFL(70,45),mirrorForFL(40,55)};
  int down[3]={mirrorForFL(115,90),mirrorForFL(45,45),mirrorForFL(55,55)};
  int push[3]={mirrorForFL(65,90),mirrorForFL(45,45),mirrorForFL(55,55)};
  moveLeg(2,lift,steps,dly); moveLeg(2,swing,steps,dly); moveLeg(2,down,steps,dly); moveLeg(2,push,steps,dly);
}

void backwardStepBR() {
  int lift[3]={mirrorForBR(90,1,90),mirrorForBR(70,2,45),mirrorForBR(40,3,55)};
  int swing[3]={mirrorForBR(115,1,90),mirrorForBR(70,2,45),mirrorForBR(40,3,55)};
  int down[3]={mirrorForBR(115,1,90),mirrorForBR(45,2,45),mirrorForBR(55,3,55)};
  int push[3]={mirrorForBR(65,1,90),mirrorForBR(45,2,45),mirrorForBR(55,3,55)};
  moveLeg(3,lift,steps,dly); moveLeg(3,swing,steps,dly); moveLeg(3,down,steps,dly); moveLeg(3,push,steps,dly);
}

// ================= TURN =================
void turnLeft(){ forwardStepFR(); backwardStepBL(); backwardStepFL(); forwardStepBR(); }
void turnRight(){ backwardStepFR(); forwardStepBL(); forwardStepFL(); backwardStepBR(); }

// ================= SENSOR =================
void readSensors() {
  for(int i=0;i<3;i++){
    digitalWrite(sensors[i].trigPin,LOW);
    delayMicroseconds(2);
    digitalWrite(sensors[i].trigPin,HIGH);
    delayMicroseconds(10);
    digitalWrite(sensors[i].trigPin,LOW);

    long duration=pulseIn(sensors[i].echoPin,HIGH,30000);
    sensors[i].distance=(duration>0)?duration*0.0343/2:999;
    sensors[i].obstacleDetected=sensors[i].distance<=THRESHOLD;
  }
}

// ================= DECISION =================
void decideMovement() {
  bool F=sensors[0].obstacleDetected;
  bool L=sensors[1].obstacleDetected;
  bool R=sensors[2].obstacleDetected;

  if(!F&&!L&&!R) currentState=FORWARD;
  else if(F&&L&&R) currentState=BACKWARD;
  else if(!F&&!L&&R) currentState=TURN_LEFT;
  else if(F&&!L&&R) currentState=TURN_LEFT;
  else if(!F&&L&&!R) currentState=TURN_RIGHT;
  else if(F&&L&&!R) currentState=TURN_RIGHT;
  else if(F&&!L&&!R) currentState=TURN_RIGHT;
  else if(!F&&L&&R) currentState=BACKWARD;
}

// ================= SETUP =================
void setup() {
  Serial.begin(115200);
  Wire.begin(21,22);

  pca9685.begin();
  pca9685.setPWMFreq(50);

  pinMode(TRIG_FRONT,OUTPUT);
  pinMode(ECHO_FRONT,INPUT);
  pinMode(TRIG_LEFT,OUTPUT);
  pinMode(ECHO_LEFT,INPUT);
  pinMode(TRIG_RIGHT,OUTPUT);
  pinMode(ECHO_RIGHT,INPUT);

  delay(500);
  standPose();

  Serial.println("AUTO WALK STARTED");
}

// ================= LOOP =================
void loop() {
  readSensors();
  decideMovement();

  switch(currentState){
    case FORWARD: walkForward(); break;
    case BACKWARD: walkBackward(); break;
    case TURN_LEFT: turnLeft(); break;
    case TURN_RIGHT: turnRight(); break;
    default: break;
  }
}

// ================= WALK WRAPPERS =================
void walkForward(){ forwardStepFR(); forwardStepBL(); forwardStepFL(); forwardStepBR(); }
void walkBackward(){ backwardStepFR(); backwardStepBL(); backwardStepFL(); backwardStepBR(); }