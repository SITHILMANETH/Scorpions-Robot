// Non-blocking version using millis()
#define TRIG_FRONT 27
#define ECHO_FRONT 26
#define TRIG_LEFT 32
#define ECHO_LEFT 33
#define TRIG_RIGHT 14
#define ECHO_RIGHT 12

struct Sensor {
  int trigPin;
  int echoPin;
  float distance;
  unsigned long lastTriggerTime;
  bool waitingForEcho;
  unsigned long echoStartTime;
};

Sensor sensors[3] = {
  {TRIG_FRONT, ECHO_FRONT, 0, 0, false, 0},
  {TRIG_LEFT, ECHO_LEFT, 0, 0, false, 0},
  {TRIG_RIGHT, ECHO_RIGHT, 0, 0, false, 0}
};

const unsigned long TRIGGER_INTERVAL = 50; // 50ms between sensor triggers
unsigned long lastTrigger = 0;
int currentSensor = 0;

void setup() {
  Serial.begin(115200);
  
  for (int i = 0; i < 3; i++) {
    pinMode(sensors[i].trigPin, OUTPUT);
    pinMode(sensors[i].echoPin, INPUT);
    digitalWrite(sensors[i].trigPin, LOW);
  }
  
  Serial.println("Multi-sensor ultrasonic system ready");
}

void loop() {
  unsigned long currentTime = millis();
  
  // Trigger sensors sequentially
  if (!sensors[currentSensor].waitingForEcho && 
      currentTime - lastTrigger >= TRIGGER_INTERVAL) {
    
    // Trigger current sensor
    digitalWrite(sensors[currentSensor].trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(sensors[currentSensor].trigPin, LOW);
    
    sensors[currentSensor].waitingForEcho = true;
    sensors[currentSensor].echoStartTime = micros();
    lastTrigger = currentTime;
    
    // Move to next sensor
    currentSensor = (currentSensor + 1) % 3;
  }
  
  // Check for echoes
  for (int i = 0; i < 3; i++) {
    if (sensors[i].waitingForEcho) {
      int duration = pulseIn(sensors[i].echoPin, HIGH, 30000);
      if (duration > 0) {
        sensors[i].distance = duration * 0.0343 / 2;
        sensors[i].waitingForEcho = false;
      } else if (micros() - sensors[i].echoStartTime > 30000) {
        sensors[i].distance = 999.0; // Timeout
        sensors[i].waitingForEcho = false;
      }
    }
  }
  
  // Print all distances every 200ms
  static unsigned long lastPrint = 0;
  if (currentTime - lastPrint >= 200) {
    lastPrint = currentTime;
    Serial.print("F:");
    Serial.print(sensors[0].distance, 1);
    Serial.print("cm L:");
    Serial.print(sensors[1].distance, 1);
    Serial.print("cm R:");
    Serial.print(sensors[2].distance, 1);
    Serial.println("cm");
  }
}