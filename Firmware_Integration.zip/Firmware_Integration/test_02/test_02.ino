#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

Adafruit_PWMServoDriver pca9685 = Adafruit_PWMServoDriver(0x40);

// ================= Servo pulse range =================
#define SERVOMIN 110
#define SERVOMAX 510

// ================= Servo Mapping =================
// FR
#define FR1 4
#define FR2 8
#define FR3 12

// BL
#define BL1 5
#define BL2 9
#define BL3 13

// FL
#define FL1 6
#define FL2 10
#define FL3 14

// BR
#define BR1 7
#define BR2 11
#define BR3 15

// ================= Home Positions =================
int FR_home[3] = {90,45,55};
int BL_home[3] = {90,45,55};
int FL_home[3] = {90,45,55};
int BR_home[3] = {90,45,55};

// ================= Current Positions =================
int FR_cur[3] = {90,45,55};
int BL_cur[3] = {90,45,55};
int FL_cur[3] = {90,45,55};
int BR_cur[3] = {90,45,55};

bool walking = false;

// =====================================================
int angleToPulse(int angle) {
  return map(angle, 0, 180, SERVOMIN, SERVOMAX);
}

void setServo(uint8_t ch, int angle) {
  angle = constrain(angle, 0, 180);
  pca9685.setPWM(ch, 0, angleToPulse(angle));
}

// ================= Smooth Move Function =================
void moveLegs(
  int FR_t[3], int BL_t[3],
  int FL_t[3], int BR_t[3],
  int steps = 25, int dly = 15
) {

  int FR_s[3] = {FR_cur[0], FR_cur[1], FR_cur[2]};
  int BL_s[3] = {BL_cur[0], BL_cur[1], BL_cur[2]};
  int FL_s[3] = {FL_cur[0], FL_cur[1], FL_cur[2]};
  int BR_s[3] = {BR_cur[0], BR_cur[1], BR_cur[2]};

  for (int i = 1; i <= steps; i++) {

    int fr1 = FR_s[0] + (FR_t[0] - FR_s[0]) * i / steps;
    int fr2 = FR_s[1] + (FR_t[1] - FR_s[1]) * i / steps;
    int fr3 = FR_s[2] + (FR_t[2] - FR_s[2]) * i / steps;

    int bl1 = BL_s[0] + (BL_t[0] - BL_s[0]) * i / steps;
    int bl2 = BL_s[1] + (BL_t[1] - BL_s[1]) * i / steps;
    int bl3 = BL_s[2] + (BL_t[2] - BL_s[2]) * i / steps;

    int fl1 = FL_s[0] + (FL_t[0] - FL_s[0]) * i / steps;
    int fl2 = FL_s[1] + (FL_t[1] - FL_s[1]) * i / steps;
    int fl3 = FL_s[2] + (FL_t[2] - FL_s[2]) * i / steps;

    int br1 = BR_s[0] + (BR_t[0] - BR_s[0]) * i / steps;
    int br2 = BR_s[1] + (BR_t[1] - BR_s[1]) * i / steps;
    int br3 = BR_s[2] + (BR_t[2] - BR_s[2]) * i / steps;

    // Apply to servos
    setServo(FR1, fr1);
    setServo(FR2, fr2);
    setServo(FR3, fr3);

    setServo(BL1, bl1);
    setServo(BL2, bl2);
    setServo(BL3, bl3);

    setServo(FL1, fl1);
    setServo(FL2, fl2);
    setServo(FL3, fl3);

    setServo(BR1, br1);
    setServo(BR2, br2);
    setServo(BR3, br3);

    delay(dly);
  }

  for (int j = 0; j < 3; j++) {
    FR_cur[j] = FR_t[j];
    BL_cur[j] = BL_t[j];
    FL_cur[j] = FL_t[j];
    BR_cur[j] = BR_t[j];
  }
}

// ================= Stand =================
void standPose() {
  moveLegs(FR_home, BL_home, FL_home, BR_home);
}

// ================= Walk Cycle =================
void walkStep1() {
  int lift[3]  = {90, 70, 40};
  int swing[3] = {65, 70, 40};
  int down[3]  = {65, 45, 55};
  int push[3]  = {115,45,55};

  // Lift FR + BL
  moveLegs(lift, lift, FL_cur, BR_cur);

  // Swing forward
  moveLegs(swing, swing, FL_cur, BR_cur);

  // Place down
  moveLegs(down, down, FL_cur, BR_cur);

  // Push body
  moveLegs(push, push, FL_cur, BR_cur);
}

void walkStep2() {
  int lift[3]  = {90, 70, 40};
  int swing[3] = {115,70,40};
  int down[3]  = {115,45,55};
  int push[3]  = {65, 45,55};

  // Lift FL + BR
  moveLegs(FR_cur, BL_cur, lift, lift);

  // Swing forward
  moveLegs(FR_cur, BL_cur, swing, swing);

  // Place down
  moveLegs(FR_cur, BL_cur, down, down);

  // Push body
  moveLegs(FR_cur, BL_cur, push, push);
}

// ================= Setup =================
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);

  pca9685.begin();
  pca9685.setPWMFreq(50);

  delay(500);

  standPose();

  Serial.println("Quadruped Ready");
}

// ================= Loop =================
void loop() {

  if (Serial.available()) {
    char cmd = Serial.read();

    if (cmd == 'H' || cmd == 'h') {
      walking = false;
      standPose();
    }

    if (cmd == 'W' || cmd == 'w') {
      walking = true;
    }

    if (cmd == 'S' || cmd == 's') {
      walking = false;
    }
  }

  if (walking) {
    walkStep1();
    walkStep2();
  }
}