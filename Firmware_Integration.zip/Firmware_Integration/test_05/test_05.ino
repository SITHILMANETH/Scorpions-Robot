// Forward and Backward good
#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

Adafruit_PWMServoDriver pca9685 = Adafruit_PWMServoDriver(0x40);

// ================= Servo pulse range =================
#define SERVOMIN 110
#define SERVOMAX 510

// ================= Servo Mapping =================
// FR (Front Right)
#define FR1 4
#define FR2 8
#define FR3 12

// BL (Back Left)
#define BL1 5
#define BL2 9
#define BL3 13

// FL (Front Left)
#define FL1 6
#define FL2 10
#define FL3 14

// BR (Back Right)
#define BR1 7
#define BR2 11
#define BR3 15

// ================= Home Positions =================
int FR_home[3] = {90, 45, 55};
int BL_home[3] = {90, 45, 55};
int FL_home[3] = {90, 45, 55};
int BR_home[3] = {90, 45, 55};

// ================= Current Positions =================
int FR_cur[3] = {90, 45, 55};
int BL_cur[3] = {90, 45, 55};
int FL_cur[3] = {90, 45, 55};
int BR_cur[3] = {90, 45, 55};

// ================= Movement State =================
enum MoveState {
  IDLE,
  FORWARD,
  BACKWARD,
  TURN_LEFT,
  TURN_RIGHT
};

MoveState currentState = IDLE;

// ================= Walk Parameters =================
int steps = 20;      // Smoothing steps
int dly = 10;        // Delay between steps (ms)

// =====================================================
int angleToPulse(int angle) {
  return map(angle, 0, 180, SERVOMIN, SERVOMAX);
}

void setServo(uint8_t ch, int angle) {
  angle = constrain(angle, 0, 180);
  pca9685.setPWM(ch, 0, angleToPulse(angle));
}

// ================= Mirror Angle Functions =================
// For FL (Front Left) - mirror all motors
int mirrorForFL(int angle, int homeAngle) {
  return constrain(2 * homeAngle - angle, 0, 180);
}

// For BL - mirror ONLY motor 1 (forward/back)
int mirrorForBL(int angle, int motorNum, int homeAngle) {
  if (motorNum == 1) {
    // Motor 1 needs mirroring for BL
    return constrain(2 * homeAngle - angle, 0, 180);
  } else {
    // Motors 2 and 3 keep original angles
    return angle;
  }
}

// For BR - mirror ONLY motor 2 (lift) and keep others original
int mirrorForBR(int angle, int motorNum, int homeAngle) {
  if (motorNum == 2) {
    // Motor 2 needs mirroring for BR (lift motor)
    return constrain(2 * homeAngle - angle, 0, 180);
  } else {
    // Motors 1 and 3 keep original angles
    return angle;
  }
}

// ================= Move Single Leg =================
void moveLeg(int leg, int target[3], int stepsNum = 20, int delayTime = 10) {
  int* current;
  int ch1, ch2, ch3;
  
  // Get current position and servo channels for the leg
  switch(leg) {
    case 0: // FR
      current = FR_cur;
      ch1 = FR1; ch2 = FR2; ch3 = FR3;
      break;
    case 1: // BL
      current = BL_cur;
      ch1 = BL1; ch2 = BL2; ch3 = BL3;
      break;
    case 2: // FL
      current = FL_cur;
      ch1 = FL1; ch2 = FL2; ch3 = FL3;
      break;
    case 3: // BR
      current = BR_cur;
      ch1 = BR1; ch2 = BR2; ch3 = BR3;
      break;
    default:
      return;
  }
  
  int s1 = current[0];
  int s2 = current[1];
  int s3 = current[2];
  
  for (int i = 1; i <= stepsNum; i++) {
    int a1 = s1 + (target[0] - s1) * i / stepsNum;
    int a2 = s2 + (target[1] - s2) * i / stepsNum;
    int a3 = s3 + (target[2] - s3) * i / stepsNum;
    
    setServo(ch1, a1);
    setServo(ch2, a2);
    setServo(ch3, a3);
    
    delay(delayTime);
  }
  
  // Update current position
  current[0] = target[0];
  current[1] = target[1];
  current[2] = target[2];
}

// ================= Move All Legs to Home =================
void standPose() {
  moveLeg(0, FR_home, 20, 8);
  moveLeg(1, BL_home, 20, 8);
  moveLeg(2, FL_home, 20, 8);
  moveLeg(3, BR_home, 20, 8);
}

// ================= FORWARD WALK (Sequential) =================
// Order: FR -> BL -> FL -> BR

void forwardStepFR() {
  // FR leg: Lift -> Swing -> Down -> Push (ORIGINAL - no mirror)
  int lift[3]  = {90, 70, 40};
  int swing[3] = {65, 70, 40};
  int down[3]  = {65, 45, 55};
  int push[3]  = {115, 45, 55};
  
  moveLeg(0, lift, steps, dly);
  moveLeg(0, swing, steps, dly);
  moveLeg(0, down, steps, dly);
  moveLeg(0, push, steps, dly);
}

void forwardStepBL() {
  // BL leg: Mirror ONLY motor 1
  int lift[3]  = {
    mirrorForBL(90, 1, 90),   // Motor 1 mirrored: 90
    mirrorForBL(70, 2, 45),   // Motor 2 original: 70
    mirrorForBL(40, 3, 55)    // Motor 3 original: 40
  };
  int swing[3] = {
    mirrorForBL(65, 1, 90),   // Motor 1 mirrored: 115
    mirrorForBL(70, 2, 45),   // Motor 2 original: 70
    mirrorForBL(40, 3, 55)    // Motor 3 original: 40
  };
  int down[3]  = {
    mirrorForBL(65, 1, 90),   // Motor 1 mirrored: 115
    mirrorForBL(45, 2, 45),   // Motor 2 original: 45
    mirrorForBL(55, 3, 55)    // Motor 3 original: 55
  };
  int push[3]  = {
    mirrorForBL(115, 1, 90),  // Motor 1 mirrored: 65
    mirrorForBL(45, 2, 45),   // Motor 2 original: 45
    mirrorForBL(55, 3, 55)    // Motor 3 original: 55
  };
  
  moveLeg(1, lift, steps, dly);
  moveLeg(1, swing, steps, dly);
  moveLeg(1, down, steps, dly);
  moveLeg(1, push, steps, dly);
}

void forwardStepFL() {
  // FL leg: Mirror ALL motors
  int lift[3]  = {
    mirrorForFL(90, 90),
    mirrorForFL(70, 45),
    mirrorForFL(40, 55)
  };
  int swing[3] = {
    mirrorForFL(65, 90),
    mirrorForFL(70, 45),
    mirrorForFL(40, 55)
  };
  int down[3]  = {
    mirrorForFL(65, 90),
    mirrorForFL(45, 45),
    mirrorForFL(55, 55)
  };
  int push[3]  = {
    mirrorForFL(115, 90),
    mirrorForFL(45, 45),
    mirrorForFL(55, 55)
  };
  
  moveLeg(2, lift, steps, dly);
  moveLeg(2, swing, steps, dly);
  moveLeg(2, down, steps, dly);
  moveLeg(2, push, steps, dly);
}

void forwardStepBR() {
  // BR leg: Mirror ONLY motor 2 (lift motor), keep motor 1 and 3 original
  int lift[3]  = {
    mirrorForBR(90, 1, 90),   // Motor 1 original: 90
    mirrorForBR(70, 2, 45),   // Motor 2 mirrored: 20
    mirrorForBR(40, 3, 55)    // Motor 3 original: 40
  };
  int swing[3] = {
    mirrorForBR(65, 1, 90),   // Motor 1 original: 65
    mirrorForBR(70, 2, 45),   // Motor 2 mirrored: 20
    mirrorForBR(40, 3, 55)    // Motor 3 original: 40
  };
  int down[3]  = {
    mirrorForBR(65, 1, 90),   // Motor 1 original: 65
    mirrorForBR(45, 2, 45),   // Motor 2 original: 45
    mirrorForBR(55, 3, 55)    // Motor 3 original: 55
  };
  int push[3]  = {
    mirrorForBR(115, 1, 90),  // Motor 1 original: 115
    mirrorForBR(45, 2, 45),   // Motor 2 original: 45
    mirrorForBR(55, 3, 55)    // Motor 3 original: 55
  };
  
  moveLeg(3, lift, steps, dly);
  moveLeg(3, swing, steps, dly);
  moveLeg(3, down, steps, dly);
  moveLeg(3, push, steps, dly);
}

// ================= BACKWARD WALK (Sequential) =================
// Order: FR -> BL -> FL -> BR

void backwardStepFR() {
  // FR leg: ORIGINAL
  int lift[3]  = {90, 70, 40};
  int swing[3] = {115, 70, 40};
  int down[3]  = {115, 45, 55};
  int push[3]  = {65, 45, 55};
  
  moveLeg(0, lift, steps, dly);
  moveLeg(0, swing, steps, dly);
  moveLeg(0, down, steps, dly);
  moveLeg(0, push, steps, dly);
}

void backwardStepBL() {
  // BL leg: Mirror ONLY motor 1
  int lift[3]  = {
    mirrorForBL(90, 1, 90),
    mirrorForBL(70, 2, 45),
    mirrorForBL(40, 3, 55)
  };
  int swing[3] = {
    mirrorForBL(115, 1, 90),
    mirrorForBL(70, 2, 45),
    mirrorForBL(40, 3, 55)
  };
  int down[3]  = {
    mirrorForBL(115, 1, 90),
    mirrorForBL(45, 2, 45),
    mirrorForBL(55, 3, 55)
  };
  int push[3]  = {
    mirrorForBL(65, 1, 90),
    mirrorForBL(45, 2, 45),
    mirrorForBL(55, 3, 55)
  };
  
  moveLeg(1, lift, steps, dly);
  moveLeg(1, swing, steps, dly);
  moveLeg(1, down, steps, dly);
  moveLeg(1, push, steps, dly);
}

void backwardStepFL() {
  // FL leg: Mirror ALL motors
  int lift[3]  = {
    mirrorForFL(90, 90),
    mirrorForFL(70, 45),
    mirrorForFL(40, 55)
  };
  int swing[3] = {
    mirrorForFL(115, 90),
    mirrorForFL(70, 45),
    mirrorForFL(40, 55)
  };
  int down[3]  = {
    mirrorForFL(115, 90),
    mirrorForFL(45, 45),
    mirrorForFL(55, 55)
  };
  int push[3]  = {
    mirrorForFL(65, 90),
    mirrorForFL(45, 45),
    mirrorForFL(55, 55)
  };
  
  moveLeg(2, lift, steps, dly);
  moveLeg(2, swing, steps, dly);
  moveLeg(2, down, steps, dly);
  moveLeg(2, push, steps, dly);
}

void backwardStepBR() {
  // BR leg: Mirror ONLY motor 2
  int lift[3]  = {
    mirrorForBR(90, 1, 90),
    mirrorForBR(70, 2, 45),
    mirrorForBR(40, 3, 55)
  };
  int swing[3] = {
    mirrorForBR(115, 1, 90),
    mirrorForBR(70, 2, 45),
    mirrorForBR(40, 3, 55)
  };
  int down[3]  = {
    mirrorForBR(115, 1, 90),
    mirrorForBR(45, 2, 45),
    mirrorForBR(55, 3, 55)
  };
  int push[3]  = {
    mirrorForBR(65, 1, 90),
    mirrorForBR(45, 2, 45),
    mirrorForBR(55, 3, 55)
  };
  
  moveLeg(3, lift, steps, dly);
  moveLeg(3, swing, steps, dly);
  moveLeg(3, down, steps, dly);
  moveLeg(3, push, steps, dly);
}

// ================= TURN LEFT (Sequential) =================
// Order: FR -> BR -> FL -> BL

void turnLeftStepFR() {
  int lift[3]  = {90, 70, 40};
  int swing[3] = {115, 70, 40};
  int down[3]  = {115, 45, 55};
  int push[3]  = {115, 45, 55};
  
  moveLeg(0, lift, steps, dly);
  moveLeg(0, swing, steps, dly);
  moveLeg(0, down, steps, dly);
  moveLeg(0, push, steps, dly);
}

void turnLeftStepBR() {
  // BR leg: Mirror ONLY motor 2
  int lift[3]  = {
    mirrorForBR(90, 1, 90),
    mirrorForBR(70, 2, 45),
    mirrorForBR(40, 3, 55)
  };
  int swing[3] = {
    mirrorForBR(115, 1, 90),
    mirrorForBR(70, 2, 45),
    mirrorForBR(40, 3, 55)
  };
  int down[3]  = {
    mirrorForBR(115, 1, 90),
    mirrorForBR(45, 2, 45),
    mirrorForBR(55, 3, 55)
  };
  int push[3]  = {
    mirrorForBR(115, 1, 90),
    mirrorForBR(45, 2, 45),
    mirrorForBR(55, 3, 55)
  };
  
  moveLeg(3, lift, steps, dly);
  moveLeg(3, swing, steps, dly);
  moveLeg(3, down, steps, dly);
  moveLeg(3, push, steps, dly);
}

void turnLeftStepFL() {
  // FL leg: Mirror ALL motors
  int lift[3]  = {
    mirrorForFL(90, 90),
    mirrorForFL(70, 45),
    mirrorForFL(40, 55)
  };
  int swing[3] = {
    mirrorForFL(65, 90),
    mirrorForFL(70, 45),
    mirrorForFL(40, 55)
  };
  int down[3]  = {
    mirrorForFL(65, 90),
    mirrorForFL(45, 45),
    mirrorForFL(55, 55)
  };
  int push[3]  = {
    mirrorForFL(65, 90),
    mirrorForFL(45, 45),
    mirrorForFL(55, 55)
  };
  
  moveLeg(2, lift, steps, dly);
  moveLeg(2, swing, steps, dly);
  moveLeg(2, down, steps, dly);
  moveLeg(2, push, steps, dly);
}

void turnLeftStepBL() {
  // BL leg: Mirror ONLY motor 1
  int lift[3]  = {
    mirrorForBL(90, 1, 90),
    mirrorForBL(70, 2, 45),
    mirrorForBL(40, 3, 55)
  };
  int swing[3] = {
    mirrorForBL(65, 1, 90),
    mirrorForBL(70, 2, 45),
    mirrorForBL(40, 3, 55)
  };
  int down[3]  = {
    mirrorForBL(65, 1, 90),
    mirrorForBL(45, 2, 45),
    mirrorForBL(55, 3, 55)
  };
  int push[3]  = {
    mirrorForBL(65, 1, 90),
    mirrorForBL(45, 2, 45),
    mirrorForBL(55, 3, 55)
  };
  
  moveLeg(1, lift, steps, dly);
  moveLeg(1, swing, steps, dly);
  moveLeg(1, down, steps, dly);
  moveLeg(1, push, steps, dly);
}

// ================= TURN RIGHT (Sequential) =================
// Order: FL -> BR -> FR -> BL

void turnRightStepFL() {
  // FL leg: Mirror ALL motors
  int lift[3]  = {
    mirrorForFL(90, 90),
    mirrorForFL(70, 45),
    mirrorForFL(40, 55)
  };
  int swing[3] = {
    mirrorForFL(115, 90),
    mirrorForFL(70, 45),
    mirrorForFL(40, 55)
  };
  int down[3]  = {
    mirrorForFL(115, 90),
    mirrorForFL(45, 45),
    mirrorForFL(55, 55)
  };
  int push[3]  = {
    mirrorForFL(115, 90),
    mirrorForFL(45, 45),
    mirrorForFL(55, 55)
  };
  
  moveLeg(2, lift, steps, dly);
  moveLeg(2, swing, steps, dly);
  moveLeg(2, down, steps, dly);
  moveLeg(2, push, steps, dly);
}

void turnRightStepBR() {
  // BR leg: Mirror ONLY motor 2
  int lift[3]  = {
    mirrorForBR(90, 1, 90),
    mirrorForBR(70, 2, 45),
    mirrorForBR(40, 3, 55)
  };
  int swing[3] = {
    mirrorForBR(115, 1, 90),
    mirrorForBR(70, 2, 45),
    mirrorForBR(40, 3, 55)
  };
  int down[3]  = {
    mirrorForBR(115, 1, 90),
    mirrorForBR(45, 2, 45),
    mirrorForBR(55, 3, 55)
  };
  int push[3]  = {
    mirrorForBR(115, 1, 90),
    mirrorForBR(45, 2, 45),
    mirrorForBR(55, 3, 55)
  };
  
  moveLeg(3, lift, steps, dly);
  moveLeg(3, swing, steps, dly);
  moveLeg(3, down, steps, dly);
  moveLeg(3, push, steps, dly);
}

void turnRightStepFR() {
  int lift[3]  = {90, 70, 40};
  int swing[3] = {65, 70, 40};
  int down[3]  = {65, 45, 55};
  int push[3]  = {65, 45, 55};
  
  moveLeg(0, lift, steps, dly);
  moveLeg(0, swing, steps, dly);
  moveLeg(0, down, steps, dly);
  moveLeg(0, push, steps, dly);
}

void turnRightStepBL() {
  // BL leg: Mirror ONLY motor 1
  int lift[3]  = {
    mirrorForBL(90, 1, 90),
    mirrorForBL(70, 2, 45),
    mirrorForBL(40, 3, 55)
  };
  int swing[3] = {
    mirrorForBL(65, 1, 90),
    mirrorForBL(70, 2, 45),
    mirrorForBL(40, 3, 55)
  };
  int down[3]  = {
    mirrorForBL(65, 1, 90),
    mirrorForBL(45, 2, 45),
    mirrorForBL(55, 3, 55)
  };
  int push[3]  = {
    mirrorForBL(65, 1, 90),
    mirrorForBL(45, 2, 45),
    mirrorForBL(55, 3, 55)
  };
  
  moveLeg(1, lift, steps, dly);
  moveLeg(1, swing, steps, dly);
  moveLeg(1, down, steps, dly);
  moveLeg(1, push, steps, dly);
}

// ================= Movement Controllers =================
void walkForward() {
  forwardStepFR();
  forwardStepBL();
  forwardStepFL();
  forwardStepBR();
}

void walkBackward() {
  backwardStepFR();
  backwardStepBL();
  backwardStepFL();
  backwardStepBR();
}

void turnLeft() {
  turnLeftStepFR();
  turnLeftStepBR();
  turnLeftStepFL();
  turnLeftStepBL();
}

void turnRight() {
  turnRightStepFL();
  turnRightStepBR();
  turnRightStepFR();
  turnRightStepBL();
}

// ================= Setup =================
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  
  pca9685.begin();
  pca9685.setPWMFreq(50);
  
  delay(500);
  
  standPose();
  
  Serial.println("Quadruped Robot Ready - BR Motor 2 Fixed (Mirrored to 20°)");
  Serial.println("==========================================================");
  Serial.println("Mirroring Strategy:");
  Serial.println("FR: No mirroring (ORIGINAL)");
  Serial.println("BL: Only Motor 1 mirrored");
  Serial.println("FL: All motors mirrored");
  Serial.println("BR: Only Motor 2 mirrored (70° → 20° for lift)");
  Serial.println("==========================================================");
  Serial.println("Commands:");
  Serial.println("F / f - Walk Forward");
  Serial.println("B / b - Walk Backward");
  Serial.println("L / l - Turn Left");
  Serial.println("R / r - Turn Right");
  Serial.println("H / h - Home/Stand Position");
  Serial.println("S / s - Stop Movement");
  Serial.println("==========================================================");
}

// ================= Loop =================
void loop() {
  if (Serial.available()) {
    char cmd = Serial.read();
    
    switch (cmd) {
      case 'F':
      case 'f':
        currentState = FORWARD;
        Serial.println("Moving FORWARD");
        break;
        
      case 'B':
      case 'b':
        currentState = BACKWARD;
        Serial.println("Moving BACKWARD");
        break;
        
      case 'L':
      case 'l':
        currentState = TURN_LEFT;
        Serial.println("Turning LEFT");
        break;
        
      case 'R':
      case 'r':
        currentState = TURN_RIGHT;
        Serial.println("Turning RIGHT");
        break;
        
      case 'H':
      case 'h':
        currentState = IDLE;
        standPose();
        Serial.println("Home/Stand position");
        break;
        
      case 'S':
      case 's':
        currentState = IDLE;
        Serial.println("Stopped");
        break;
    }
  }
  
  // Execute movement based on current state
  switch (currentState) {
    case FORWARD:
      walkForward();
      break;
      
    case BACKWARD:
      walkBackward();
      break;
      
    case TURN_LEFT:
      turnLeft();
      break;
      
    case TURN_RIGHT:
      turnRight();
      break;
      
    case IDLE:
    default:
      break;
  }
}