w
#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

Adafruit_PWMServoDriver pca9685 = Adafruit_PWMServoDriver(0x40);

// ================= Servo pulse range =================
#define SERVOMIN 110
#define SERVOMAX 510

// ================= Servo Mapping =================
// FR
#define FR1 4
#define FR2 8
#define FR3 12

// BL
#define BL1 5
#define BL2 9
#define BL3 13

// FL
#define FL1 6
#define FL2 10
#define FL3 14

// BR
#define BR1 7
#define BR2 11
#define BR3 15

// ================= Home Positions =================
// All legs have same home position (90, 45, 55)
int FR_home[3] = {90, 45, 55};
int BL_home[3] = {90, 45, 55};
int FL_home[3] = {90, 45, 55};
int BR_home[3] = {90, 45, 55};

// ================= Current Positions =================
int FR_cur[3] = {90, 45, 55};
int BL_cur[3] = {90, 45, 55};
int FL_cur[3] = {90, 45, 55};
int BR_cur[3] = {90, 45, 55};

// ================= Movement State =================
enum MoveState {
  IDLE,
  FORWARD,
  BACKWARD,
  TURN_LEFT,
  TURN_RIGHT
};

MoveState currentState = IDLE;

// ================= Walk Parameters =================
int steps = 25;      // Smoothing steps
int dly = 12;        // Delay between steps (ms) - lower = faster
int turnDly = 10;    // Faster turning

// =====================================================
int angleToPulse(int angle) {
  return map(angle, 0, 180, SERVOMIN, SERVOMAX);
}

void setServo(uint8_t ch, int angle) {
  angle = constrain(angle, 0, 180);
  pca9685.setPWM(ch, 0, angleToPulse(angle));
}

// ================= Mirror Angle for FL and BR =================
// FL and BR need angles mirrored relative to home position
int mirrorForFLBR(int angle, int homeAngle) {
  return constrain(2 * homeAngle - angle, 0, 180);
}

// ================= Smooth Move Function =================
void moveLegs(
  int FR_t[3], int BL_t[3],
  int FL_t[3], int BR_t[3],
  int stepsNum = 25, int delayTime = 15
) {

  int FR_s[3] = {FR_cur[0], FR_cur[1], FR_cur[2]};
  int BL_s[3] = {BL_cur[0], BL_cur[1], BL_cur[2]};
  int FL_s[3] = {FL_cur[0], FL_cur[1], FL_cur[2]};
  int BR_s[3] = {BR_cur[0], BR_cur[1], BR_cur[2]};

  for (int i = 1; i <= stepsNum; i++) {

    int fr1 = FR_s[0] + (FR_t[0] - FR_s[0]) * i / stepsNum;
    int fr2 = FR_s[1] + (FR_t[1] - FR_s[1]) * i / stepsNum;
    int fr3 = FR_s[2] + (FR_t[2] - FR_s[2]) * i / stepsNum;

    int bl1 = BL_s[0] + (BL_t[0] - BL_s[0]) * i / stepsNum;
    int bl2 = BL_s[1] + (BL_t[1] - BL_s[1]) * i / stepsNum;
    int bl3 = BL_s[2] + (BL_t[2] - BL_s[2]) * i / stepsNum;

    int fl1 = FL_s[0] + (FL_t[0] - FL_s[0]) * i / stepsNum;
    int fl2 = FL_s[1] + (FL_t[1] - FL_s[1]) * i / stepsNum;
    int fl3 = FL_s[2] + (FL_t[2] - FL_s[2]) * i / stepsNum;

    int br1 = BR_s[0] + (BR_t[0] - BR_s[0]) * i / stepsNum;
    int br2 = BR_s[1] + (BR_t[1] - BR_s[1]) * i / stepsNum;
    int br3 = BR_s[2] + (BR_t[2] - BR_s[2]) * i / stepsNum;

    // Apply to servos
    setServo(FR1, fr1);
    setServo(FR2, fr2);
    setServo(FR3, fr3);

    setServo(BL1, bl1);
    setServo(BL2, bl2);
    setServo(BL3, bl3);

    setServo(FL1, fl1);
    setServo(FL2, fl2);
    setServo(FL3, fl3);

    setServo(BR1, br1);
    setServo(BR2, br2);
    setServo(BR3, br3);

    delay(delayTime);
  }

  for (int j = 0; j < 3; j++) {
    FR_cur[j] = FR_t[j];
    BL_cur[j] = BL_t[j];
    FL_cur[j] = FL_t[j];
    BR_cur[j] = BR_t[j];
  }
}

// ================= Stand =================
void standPose() {
  moveLegs(FR_home, BL_home, FL_home, BR_home, 20, 10);
}

// ================= FORWARD WALK =================
void forwardStep1() {
  // FR and BL moving forward (original angles)
  int FRBL_lift[3]  = {90, 70, 40};    // Lift position
  int FRBL_swing[3] = {65, 70, 40};    // Swing forward position
  int FRBL_down[3]  = {65, 45, 55};    // Place down position
  int FRBL_push[3]  = {115, 45, 55};   // Push backward position
  
  // FL and BR remain in push position (mirrored)
  int FLBR_push[3] = {
    mirrorForFLBR(115, 90),   // Motor1: 65
    mirrorForFLBR(45, 45),    // Motor2: 45
    mirrorForFLBR(55, 55)     // Motor3: 55
  };
  
  moveLegs(FRBL_lift, FRBL_lift, FLBR_push, FLBR_push, steps, dly);
  moveLegs(FRBL_swing, FRBL_swing, FLBR_push, FLBR_push, steps, dly);
  moveLegs(FRBL_down, FRBL_down, FLBR_push, FLBR_push, steps, dly);
  moveLegs(FRBL_push, FRBL_push, FLBR_push, FLBR_push, steps, dly);
}

void forwardStep2() {
  // FR and BL remain in push position (original angles)
  int FRBL_push[3] = {115, 45, 55};
  
  // FL and BR moving forward (mirrored angles)
  int FLBR_lift[3] = {
    mirrorForFLBR(90, 90),    // Motor1: 90
    mirrorForFLBR(70, 45),    // Motor2: 20
    mirrorForFLBR(40, 55)     // Motor3: 70
  };
  
  int FLBR_swing[3] = {
    mirrorForFLBR(65, 90),    // Motor1: 115
    mirrorForFLBR(70, 45),    // Motor2: 20
    mirrorForFLBR(40, 55)     // Motor3: 70
  };
  
  int FLBR_down[3] = {
    mirrorForFLBR(65, 90),    // Motor1: 115
    mirrorForFLBR(45, 45),    // Motor2: 45
    mirrorForFLBR(55, 55)     // Motor3: 55
  };
  
  int FLBR_push[3] = {
    mirrorForFLBR(115, 90),   // Motor1: 65
    mirrorForFLBR(45, 45),    // Motor2: 45
    mirrorForFLBR(55, 55)     // Motor3: 55
  };
  
  moveLegs(FRBL_push, FRBL_push, FLBR_lift, FLBR_lift, steps, dly);
  moveLegs(FRBL_push, FRBL_push, FLBR_swing, FLBR_swing, steps, dly);
  moveLegs(FRBL_push, FRBL_push, FLBR_down, FLBR_down, steps, dly);
  moveLegs(FRBL_push, FRBL_push, FLBR_push, FLBR_push, steps, dly);
}

// ================= BACKWARD WALK =================
void backwardStep1() {
  // FR and BL moving backward (original angles reversed)
  int FRBL_lift[3]  = {90, 70, 40};     // Lift position
  int FRBL_swing[3] = {115, 70, 40};    // Swing backward position
  int FRBL_down[3]  = {115, 45, 55};    // Place down position
  int FRBL_push[3]  = {65, 45, 55};     // Push forward position
  
  // FL and BR remain in push position (mirrored)
  int FLBR_push[3] = {
    mirrorForFLBR(65, 90),    // Motor1: 115
    mirrorForFLBR(45, 45),    // Motor2: 45
    mirrorForFLBR(55, 55)     // Motor3: 55
  };
  
  moveLegs(FRBL_lift, FRBL_lift, FLBR_push, FLBR_push, steps, dly);
  moveLegs(FRBL_swing, FRBL_swing, FLBR_push, FLBR_push, steps, dly);
  moveLegs(FRBL_down, FRBL_down, FLBR_push, FLBR_push, steps, dly);
  moveLegs(FRBL_push, FRBL_push, FLBR_push, FLBR_push, steps, dly);
}

void backwardStep2() {
  // FR and BL remain in push position (original angles reversed)
  int FRBL_push[3] = {65, 45, 55};
  
  // FL and BR moving backward (mirrored angles reversed)
  int FLBR_lift[3] = {
    mirrorForFLBR(90, 90),    // Motor1: 90
    mirrorForFLBR(70, 45),    // Motor2: 20
    mirrorForFLBR(40, 55)     // Motor3: 70
  };
  
  int FLBR_swing[3] = {
    mirrorForFLBR(115, 90),   // Motor1: 65
    mirrorForFLBR(70, 45),    // Motor2: 20
    mirrorForFLBR(40, 55)     // Motor3: 70
  };
  
  int FLBR_down[3] = {
    mirrorForFLBR(115, 90),   // Motor1: 65
    mirrorForFLBR(45, 45),    // Motor2: 45
    mirrorForFLBR(55, 55)     // Motor3: 55
  };
  
  int FLBR_push[3] = {
    mirrorForFLBR(65, 90),    // Motor1: 115
    mirrorForFLBR(45, 45),    // Motor2: 45
    mirrorForFLBR(55, 55)     // Motor3: 55
  };
  
  moveLegs(FRBL_push, FRBL_push, FLBR_lift, FLBR_lift, steps, dly);
  moveLegs(FRBL_push, FRBL_push, FLBR_swing, FLBR_swing, steps, dly);
  moveLegs(FRBL_push, FRBL_push, FLBR_down, FLBR_down, steps, dly);
  moveLegs(FRBL_push, FRBL_push, FLBR_push, FLBR_push, steps, dly);
}

// ================= TURN LEFT =================
// Turning left: FR and BR push forward, FL and BL push backward
void turnLeftStep1() {
  // FR and BR moving forward (push)
  int FR_push[3] = {115, 45, 55};      // FR push forward
  int BR_push[3] = {
    mirrorForFLBR(115, 90),            // BR push forward (mirrored)
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  
  // FL and BL moving backward (push)
  int FL_push[3] = {
    mirrorForFLBR(65, 90),             // FL push backward (mirrored)
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  int BL_push[3] = {65, 45, 55};       // BL push backward
  
  // Lift phase
  int FR_lift[3] = {90, 70, 40};
  int BR_lift[3] = {
    mirrorForFLBR(90, 90),
    mirrorForFLBR(70, 45),
    mirrorForFLBR(40, 55)
  };
  int FL_lift[3] = {
    mirrorForFLBR(90, 90),
    mirrorForFLBR(70, 45),
    mirrorForFLBR(40, 55)
  };
  int BL_lift[3] = {90, 70, 40};
  
  // Swing phase
  int FR_swing[3] = {115, 70, 40};
  int BR_swing[3] = {
    mirrorForFLBR(115, 90),
    mirrorForFLBR(70, 45),
    mirrorForFLBR(40, 55)
  };
  int FL_swing[3] = {
    mirrorForFLBR(65, 90),
    mirrorForFLBR(70, 45),
    mirrorForFLBR(40, 55)
  };
  int BL_swing[3] = {65, 70, 40};
  
  // Down phase
  int FR_down[3] = {115, 45, 55};
  int BR_down[3] = {
    mirrorForFLBR(115, 90),
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  int FL_down[3] = {
    mirrorForFLBR(65, 90),
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  int BL_down[3] = {65, 45, 55};
  
  moveLegs(FR_lift, BL_lift, FL_lift, BR_lift, steps, turnDly);
  moveLegs(FR_swing, BL_swing, FL_swing, BR_swing, steps, turnDly);
  moveLegs(FR_down, BL_down, FL_down, BR_down, steps, turnDly);
  moveLegs(FR_push, BL_push, FL_push, BR_push, steps, turnDly);
}

void turnLeftStep2() {
  // FR and BR remain in push position
  int FR_push[3] = {115, 45, 55};
  int BR_push[3] = {
    mirrorForFLBR(115, 90),
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  
  // FL and BL moving (alternating legs for turn)
  int FL_lift[3] = {
    mirrorForFLBR(90, 90),
    mirrorForFLBR(70, 45),
    mirrorForFLBR(40, 55)
  };
  int BL_lift[3] = {90, 70, 40};
  
  int FL_swing[3] = {
    mirrorForFLBR(65, 90),
    mirrorForFLBR(70, 45),
    mirrorForFLBR(40, 55)
  };
  int BL_swing[3] = {65, 70, 40};
  
  int FL_down[3] = {
    mirrorForFLBR(65, 90),
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  int BL_down[3] = {65, 45, 55};
  
  int FL_push_back[3] = {
    mirrorForFLBR(65, 90),
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  int BL_push_back[3] = {65, 45, 55};
  
  moveLegs(FR_push, BL_lift, FL_lift, BR_push, steps, turnDly);
  moveLegs(FR_push, BL_swing, FL_swing, BR_push, steps, turnDly);
  moveLegs(FR_push, BL_down, FL_down, BR_push, steps, turnDly);
  moveLegs(FR_push, BL_push_back, FL_push_back, BR_push, steps, turnDly);
}

// ================= TURN RIGHT =================
// Turning right: FL and BR push forward, FR and BL push backward
void turnRightStep1() {
  // FL and BR moving forward (push)
  int FL_push[3] = {
    mirrorForFLBR(115, 90),            // FL push forward (mirrored)
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  int BR_push[3] = {
    mirrorForFLBR(115, 90),            // BR push forward (mirrored)
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  
  // FR and BL moving backward (push)
  int FR_push[3] = {65, 45, 55};       // FR push backward
  int BL_push[3] = {65, 45, 55};       // BL push backward
  
  // Lift phase
  int FL_lift[3] = {
    mirrorForFLBR(90, 90),
    mirrorForFLBR(70, 45),
    mirrorForFLBR(40, 55)
  };
  int BR_lift[3] = {
    mirrorForFLBR(90, 90),
    mirrorForFLBR(70, 45),
    mirrorForFLBR(40, 55)
  };
  int FR_lift[3] = {90, 70, 40};
  int BL_lift[3] = {90, 70, 40};
  
  // Swing phase
  int FL_swing[3] = {
    mirrorForFLBR(115, 90),
    mirrorForFLBR(70, 45),
    mirrorForFLBR(40, 55)
  };
  int BR_swing[3] = {
    mirrorForFLBR(115, 90),
    mirrorForFLBR(70, 45),
    mirrorForFLBR(40, 55)
  };
  int FR_swing[3] = {65, 70, 40};
  int BL_swing[3] = {65, 70, 40};
  
  // Down phase
  int FL_down[3] = {
    mirrorForFLBR(115, 90),
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  int BR_down[3] = {
    mirrorForFLBR(115, 90),
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  int FR_down[3] = {65, 45, 55};
  int BL_down[3] = {65, 45, 55};
  
  moveLegs(FR_lift, BL_lift, FL_lift, BR_lift, steps, turnDly);
  moveLegs(FR_swing, BL_swing, FL_swing, BR_swing, steps, turnDly);
  moveLegs(FR_down, BL_down, FL_down, BR_down, steps, turnDly);
  moveLegs(FR_push, BL_push, FL_push, BR_push, steps, turnDly);
}

void turnRightStep2() {
  // FL and BR remain in push position
  int FL_push[3] = {
    mirrorForFLBR(115, 90),
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  int BR_push[3] = {
    mirrorForFLBR(115, 90),
    mirrorForFLBR(45, 45),
    mirrorForFLBR(55, 55)
  };
  
  // FR and BL moving (alternating legs for turn)
  int FR_lift[3] = {90, 70, 40};
  int BL_lift[3] = {90, 70, 40};
  
  int FR_swing[3] = {65, 70, 40};
  int BL_swing[3] = {65, 70, 40};
  
  int FR_down[3] = {65, 45, 55};
  int BL_down[3] = {65, 45, 55};
  
  int FR_push_back[3] = {65, 45, 55};
  int BL_push_back[3] = {65, 45, 55};
  
  moveLegs(FR_lift, BL_lift, FL_push, BR_push, steps, turnDly);
  moveLegs(FR_swing, BL_swing, FL_push, BR_push, steps, turnDly);
  moveLegs(FR_down, BL_down, FL_push, BR_push, steps, turnDly);
  moveLegs(FR_push_back, BL_push_back, FL_push, BR_push, steps, turnDly);
}

// ================= Movement Controllers =================
void walkForward() {
  forwardStep1();
  forwardStep2();
}

void walkBackward() {
  backwardStep1();
  backwardStep2();
}

void turnLeft() {
  turnLeftStep1();
  turnLeftStep2();
}

void turnRight() {
  turnRightStep1();
  turnRightStep2();
}

// ================= Setup =================
void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22);
  
  pca9685.begin();
  pca9685.setPWMFreq(50);
  
  delay(500);
  
  standPose();
  
  Serial.println("Quadruped Robot Ready");
  Serial.println("=================================");
  Serial.println("Commands:");
  Serial.println("F / f - Walk Forward");
  Serial.println("B / b - Walk Backward");
  Serial.println("L / l - Turn Left");
  Serial.println("R / r - Turn Right");
  Serial.println("H / h - Home/Stand Position");
  Serial.println("S / s - Stop Movement");
  Serial.println("=================================");
}

// ================= Loop =================
void loop() {
  if (Serial.available()) {
    char cmd = Serial.read();
    
    switch (cmd) {
      case 'F':
      case 'f':
        currentState = FORWARD;
        Serial.println("Moving FORWARD");
        break;
        
      case 'B':
      case 'b':
        currentState = BACKWARD;
        Serial.println("Moving BACKWARD");
        break;
        
      case 'L':
      case 'l':
        currentState = TURN_LEFT;
        Serial.println("Turning LEFT");
        break;
        
      case 'R':
      case 'r':
        currentState = TURN_RIGHT;
        Serial.println("Turning RIGHT");
        break;
        
      case 'H':
      case 'h':
        currentState = IDLE;
        standPose();
        Serial.println("Home/Stand position");
        break;
        
      case 'S':
      case 's':
        currentState = IDLE;
        Serial.println("Stopped");
        break;
    }
  }
  
  // Execute movement based on current state
  switch (currentState) {
    case FORWARD:
      walkForward();
      break;
      
    case BACKWARD:
      walkBackward();
      break;
      
    case TURN_LEFT:
      turnLeft();
      break;
      
    case TURN_RIGHT:
      turnRight();
      break;
      
    case IDLE:
    default:
      // Do nothing, maintain current pose
      break;
  }
}